import objects
import time
import playercords
import graphics
def player():
    while True:
        a = input("wasd")
        if a == str("a"):
            playercords.x = playercords.x - 1
        if a == str("d"):
            playercords.x = playercords.x + 1
        time.sleep(.5)
        if playercords.y != objects.y:
             playercords.y = playercords.y + 1
        if playercords.y == objects.y:
          if playercords.x == objects.x:
              print("Collision Detected")
        if playercords.y == objects.y:
            if playercords.x != objects.x:
                playercords.y = playercords.y + 1
        graphics.graphics()
player()
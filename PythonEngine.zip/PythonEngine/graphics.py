z = 1
import playercords
import objects
def graphics():
    for z in range(playercords.y):
      if playercords.y != objects.y:
            print("0000000")
    if playercords.x == 0:
        print("0001000")
    if playercords.x == 1:
        print("0000100")
    if playercords.x == 2:
        print("0000010")
    if playercords.x == 3:
        print("0000001")
    if playercords.x == -1:
        print("0010000")
    if playercords.x == -2:
        print("0100000")
    if playercords.x == -3:
        print("1000000")
